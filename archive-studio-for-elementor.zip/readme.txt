=== Archive Studio Elementor ===
Contributors: khan9
Tags: elementor, archive layout, custom archive, blog layout, masonry grid
Requires at least: 5.4
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This addon includes 4 professionally designed archive layouts:

- Grid Layout

- Masonry Layout

- Portrait Layout

- Portrait Card Layout